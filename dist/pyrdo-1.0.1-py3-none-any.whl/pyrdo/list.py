# 定义dict_keys_list
def dict_keys_list(dict):
    res =  [i for i in dict.keys()]
    return res
# 定义dict_values_list
def dict_values_list(dict):
    res = [i for i in dict.values()]
    return res